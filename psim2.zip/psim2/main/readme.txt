Import following folders from fsim:
	/allinone
	/common
	/h264
	/java
	/mips

Must use "_ALLBUILD" and "_PERFBUILD" as preprocessor

Optional flag:
_INCLUDE_PROFILER = includes the psim profiler